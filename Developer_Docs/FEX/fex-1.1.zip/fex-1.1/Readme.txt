﻿Copyright © 2018, Timur Vizaev
timur.vizaev@gmail.com
www.f-e-x.com

Version: 1.1 [15/07/2018]

Release Notes:
- Scripting Engine
- Material Orientation Verification
- Grouping by Include Path
- BugFix] CORD2C/CORD2R reference chain is now handled correctly

FEX (FEM Explorer) is a small, yet powerful tool for helping structural
engineers to view and verify Finite Elements Method models.
FEX reads Nastran Input Files (*.dat, *.bdf, *.blk) in any format (small/large/free field).

You will need at least Windows 7 (.NET Framework 4.0) for running properly this software.
If rotation/zoom is extremely slow even with small models, please update your graphic card drivers.

The following Nastran Cards are supported in current version (1.1):

- Nodes:
	• GRID

- Elements:
	• CONM2
	• CBUSH
	• CDAMP2
	• CELAS1
	• CELAS2
	• CGAP
	• CBAR
	• CBEAM
	• CONROD
	• CROD
	• CQUAD
	• CQUAD4
	• CQUAD8
	• CQUADR
	• CQUADX
	• CSHEAR
	• CTRIA3
	• CTRIA6
	• CTRIAR
	• CTRIAX
	• CTRIAX6
	• CHEXA
	• CPENTA
	• CTETRA
	
- MPCs:
	• RBAR
	• RBE2
	• RBE3
	• RSPLINE

- Materials:
	• MAT1
	• MAT2
	• MAT4
	• MAT8
	• MAT9
	• MAT10

- Properties:
	• PBUSH
	• PELAS
	• PGAP
	• PBAR
	• PBARL
	• PBEAM
	• PBEAML
	• PROD
	• PSHEAR
	• PSHELL
	• PCOMP
	• PCOMPG
	• PSOLID
	
- Coordinate Systems:
	• CORD1R
	• CORD2C
	• CORD2R
	• CORD2S

- Loads:
	• FORCE
	• LOAD
	• PLOAD1
	• PLOAD4
	• GRAV

- SPCs:
	• SPCADD
	• SPC
	• SPC1
	• SPCD


If you have any issues in using FEX, or need some extra functionality, please
send me an email with your suggestions. I can't guarantee an instant response
but your critics and suggestions will be taken into account for future versions.

DISTRIBUTION

YOU HAVE THE FREEDOM TO COPY AND DISTRIBUTE THIS SOFTWARE AS
MANY TIMES AS YOU WANT, INCLUDING IN ALL CASES THIS UNMODIFIED
DOCUMENT. REDISTRIBUTION OF THIS SOFTWARE SHALL BE FREE OF ALL
CHARGES OR FEES TO THE RECIPIENT OF THIS SOFTWARE.

NO WARRANTY

BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR
THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY 
GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE
USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS
OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.



FEX uses HelixToolkit (MIT license)
FEX uses MahApps (Microsoft Public License)
FEX Logo was made using Unsteady Oversteer font by Typodermin Fonts.

Copyright © 2018, Timur Vizaev