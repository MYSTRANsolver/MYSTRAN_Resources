public static void Copy(string text) { Clipboard.SetDataObject(text); }

public static void Run(string scriptName) { MediatorProxy.NotifyColleagues("Run", scriptName); }

public static void Select(string input) { MediatorProxy.NotifyColleagues("Select", input); }
public static void Find(string input) { MediatorProxy.NotifyColleagues("Find", input); }

public static void ExtendElements() { MediatorProxy.NotifyColleagues("ExtendElements", null); }
public static void ExtendNodes() { MediatorProxy.NotifyColleagues("ExtendNodes", null); }
public static void ExtendMPCs() { MediatorProxy.NotifyColleagues("ExtendMPCs", null); }
public static void ExtendMaterial() { MediatorProxy.NotifyColleagues("ExtendMaterial", null); }
public static void ExtendProperty() { MediatorProxy.NotifyColleagues("ExtendProperty", null); }

public static Node NearestNode(Node g, DataFEM fem) { return fem.Nodes.Where(n=>n.ID != g.ID).MinBy(n => n.P.DistanceTo(g.P)); }
public static Node NearestNode(Node g, List<Node> grids) { return grids.Where(n=>n.ID != g.ID).MinBy(n => n.P.DistanceTo(g.P)); }
public static CoordinateSystem NearestCoord(Node g) { return g.FEM.Systems.MinBy(s=>s.Geometry.A.DistanceTo(g.P)); }

public static void Move(List<Node> nodes, double x = 0, double y = 0, double z = 0){ Move(nodes, new TimPoint3D(x, y, z)); }
public static void Move(List<Node> nodes, TimPoint3D p){ if(nodes.Any())	{ nodes.ForEach(n => n.P += p);	} }
public static void Move(List<Element> elements, double x = 0, double y = 0, double z = 0){ Move(elements, new TimPoint3D(x, y, z)); }
public static void Move(List<Element> elements, TimPoint3D p) { Move(elements.SelectMany(e => e.Nodes).Distinct().ToList(), p); }
public static void Move(List<MPC> mpcs, double x = 0, double y = 0, double z = 0){ Move(mpcs, new TimPoint3D(x, y, z)); }
public static void Move(List<MPC> mpcs, TimPoint3D p) { Move(mpcs.SelectMany(e => e.Nodes).Distinct().ToList(), p); }

public static TimPlane3D PlaneOf(Element element)
{
	if(element is Element2D)
    { return new TimPlane3D(((Element2D)element).Normal, element.Centroid); }
	else { return null; }
}


public static void JoinWithRBE2(List<Node> grids, DataFEM fem, double maxDistance = 100)
{
	var attachedGrids = new List<Node>();
	
	for(int i=0; i<grids.Count; i++)
	{
		var g = grids[i];
		if(attachedGrids.Contains(g)) { continue; }
		var nearest = NearestNode(g, fem);
		if(g.P.DistanceTo(nearest.P) > maxDistance) { continue; }
		
		attachedGrids.Add(g);
		attachedGrids.Add(nearest);
		
		var rbe2 = new RBE2();
		rbe2.Nodes.Add(g);
		rbe2.Nodes.Add(nearest);
		rbe2.DOF = 123456;
		fem.AddMPC(rbe2);
	}
}

public static CORD2R BuildNormalCoord(Node grid)
{
	CORD2R cord2r = new CORD2R();	
	var gEdges = new List<Node>();
	grid.Elements.FindEdges(ref gEdges, false);
	var g1 = grid;
	gEdges = gEdges.Where(g => g.P.DistanceTo(g1.P) > 0).ToList();
	var g2 = gEdges.First();
	var i = new TimVector3D(g1.P, g2.P);
	var k = grid.Elements.OfType<Element2D>().First(e=>e.Nodes.Contains(g1) && e.Nodes.Contains(g2)).Normal;
	var j = k ^ i;	
	
	if(g1.Elements.Any(e=> Math.Abs(TimVector3D.AngleBetween(j, new TimVector3D(g1.P, e.Centroid)).ToDegrees()) < 90))
	{
		i = -i;
		j = -j;
	}
	
	cord2r.Geometry = new CoordGeometry(i, j, k);
	cord2r.Geometry.A = g1.P;
	cord2r.Geometry.GenerarPuntos();
	cord2r.UpdateFields();
	cord2r.IsModified = true;
	return cord2r;
}

public static void BuildNormalCoords(List<Node> grids, DataFEM fem, bool nodeID = true)
{
	foreach(var g in grids)
	{
		var cord = BuildNormalCoord(g);
		if(nodeID) { cord.ID = g.ID; }
		else { cord.ID = fem.SistemasMaxID + 1; fem.Systems.Add(cord); fem.ResetFEMMaxMinIDs(); return;}
		fem.Systems.Add(cord);
	}
}

public static void RotateCoord(CoordinateSystem cord, TimVector3D axisVector, double angle = 1)
{
	var Q = TimMatrix3D.Zero;
	angle /= (180 / Math.PI);
	Q = TimMatrix3D.RotationMatrix(axisVector, angle); 
	
	var vecB = (cord.Geometry.B - cord.Geometry.A).ToTimVector3D();
	var vecC = (cord.Geometry.C - cord.Geometry.A).ToTimVector3D();
	
	var vecBrot = Q * vecB;
	var vecCrot = Q * vecC;
	
	
	cord.Geometry.B = vecBrot.ToTimPoint3D() + cord.Geometry.A;
	cord.Geometry.C = vecCrot.ToTimPoint3D() + cord.Geometry.A;
	
	cord.Geometry.BuildAxes();
}

public static void Group(List<Element> elements, FEX.File file, string name = null)
{
	if(name == null) { name = "Group " + file.Groups.Count; }
	var group = file.Groups.FirstOrDefault( g => g.Name == name);
	if(group == null) { group = new Group(name, file); file.Groups.Add(group); }
	group.Add(elements);
	group.Build3D();
	Print(group.Name + " created.");
}

public static void Group(Element element, FEX.File file, string name = null)
{
	Group(new List<Element> {element}, file, name);
}

public static string MakeSet(List<Element> elements, int idSet = 1)
{
	var set = elements.ToPatranString().Replace("Element ", "").Replace(" ", ", ").Replace(":", " THRU ");
	set = "SET " + idSet + " = " + set;
	set = set.SplitToLines().Aggregate((x, y) => x + "\r\n" + y);
	return set.Substring(0, set.Length - 2);
}

public static string MakeSet(List<Node> nodes, int idSet = 1)
{
	var set = nodes.ToPatranString().Replace("Node ", "").Replace(" ", ", ").Replace(":", " THRU ");
	set = "SET " + idSet + " = " + set;
	set = set.SplitToLines().Aggregate((x, y) => x + "\r\n" + y);
	return set.Substring(0, set.Length - 2);
}