
public void WriteSPC(string input, string dof = "123456")
{
	string path = GetPath();
	var packs = input.Split(' ');

	foreach(var pack in packs )
	{
	  if(!pack.Contains(":"))
	  {
		   string pload = "SPC1    2       " + dof.PadRight(8) + pack.ToString().PadRight(8);
		   Write(path, pload);
	  }
	  else
	  {
		var fields = pack.Split(':');
		   string pload = "SPC1    2       " + dof.PadRight(8) +  fields[0].ToString().PadRight(8) + "THRU".PadRight(8) + fields[1].ToString().PadRight(8);
		   Write(path, pload);
	  }
	}
}

public void WritePLOAD(string input, string load = "0.01")
{
	string path = GetPath();
	var packs = input.Split(' ');

	foreach(var pack in packs )
	{
	  if(!pack.Contains(":"))
	  {
		   string pload = "PLOAD4  1       " + pack.ToString().PadRight(8) + load;
		   Write(path, pload);
	  }
	  else
	  {
		var fields = pack.Split(':');
		   string pload = "PLOAD4  1       " + fields[0].ToString().PadRight(8) + load.PadRight(32) + fields[1].ToString().PadRight(8);
		   Write(path, pload);
	  }
	}
}