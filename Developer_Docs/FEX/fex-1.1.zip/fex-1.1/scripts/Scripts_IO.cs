public static void Print(object message){ Log.Print(message.ToString()); }


//Writing to files
public static string GetPath()
{
   var saveFileDialog = new Microsoft.Win32.SaveFileDialog();
   if(saveFileDialog.ShowDialog() == true) { return saveFileDialog.FileName; }
   return null;
}

public static void Write(string path, string linea)
{
	if (!System.IO.File.Exists(path)) 
    {
        using (StreamWriter sw = System.IO.File.CreateText(path)) 
        {
            sw.WriteLine(linea);
        }	
    }
	else
	{
		using (StreamWriter sw = System.IO.File.AppendText(path)) 
		{
			sw.WriteLine(linea);
		}	
	}
}

public static List<string> Read(string path)
{
	return System.IO.File.ReadAllLines(path).ToList();
}

public static List<string> ReadFile()
{
	var openFileDialog = new Microsoft.Win32.OpenFileDialog();
	if(openFileDialog.ShowDialog() == true) { return System.IO.File.ReadAllLines(openFileDialog.FileName).ToList(); }
	return null;
}

public static List<string> Split(string linea, char[] chars = null)
{
	if(chars == null) { chars =  new char[] { ',', ';' }; }
	return linea.Split(chars, StringSplitOptions.RemoveEmptyEntries).ToList();
}



public static void ExportAll(string filename, DataFEM fem)
{
	BDFWriter writer = new BDFWriter(fem.Cards());
    writer.Write(filename);
}

public static void ExportCards(string filename, List<Card> tarjetas)
{
	BDFWriter writer = new BDFWriter(tarjetas);
    writer.Write(filename);
}

public static void AddToClipboard(string str)
{
	 var str0 =  Clipboard.GetText();
	 Clipboard.SetText(str0 + "\n" + str);
}


