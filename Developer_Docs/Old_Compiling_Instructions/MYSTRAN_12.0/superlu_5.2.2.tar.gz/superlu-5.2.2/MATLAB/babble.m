% BABBLE    Set the sparse monitor flag to very verbose.
spparms('spumoni', 2);