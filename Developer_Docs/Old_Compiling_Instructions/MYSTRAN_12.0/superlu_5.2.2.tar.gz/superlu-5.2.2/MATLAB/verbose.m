% VERBOSE    Set the sparse monitor flag to verbose.
spparms('spumoni', 1);
