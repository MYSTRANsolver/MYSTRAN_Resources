If compiling for Windows, no changes need to be made to the source code.
To compile MYSTRAN, you may use one of the processes dicussed on the MYSTRAN forum.