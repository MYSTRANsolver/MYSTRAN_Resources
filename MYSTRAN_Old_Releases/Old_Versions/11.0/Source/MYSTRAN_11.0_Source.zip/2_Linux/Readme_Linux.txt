If compiling for Linux, make the following modifications to the source code.
Note that these are just modifications to the source code and not instructions for how to compile MYSTRAN.
For compiling advice, see the MYSTRAN forum.

1. Rename the other 3 files in this directory to have a ".f90" extension instead of a ".tmp" extension.
2. Delete the files in the "1_Windows" directory.