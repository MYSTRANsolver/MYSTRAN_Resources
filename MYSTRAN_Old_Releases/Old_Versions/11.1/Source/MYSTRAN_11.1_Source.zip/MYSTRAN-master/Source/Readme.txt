ADDITIONAL FILES
----------------
Additional files are located on the MYSTRAN forum: https://www.mystran.com/forums/showthread.php?tid=39
- User Manual and Other Documentation
- Test Runs
- Windows EXE (for most current official version)
- Source Code in Zip form (for most current official version)

COMPILING
---------
Processes to compile MYSTRAN are on the MYSTRAN forum: https://www.mystran.com/forums/showthread.php?tid=2