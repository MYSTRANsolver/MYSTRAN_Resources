Windows - The MYSTRAN.exe file may be used in a direct manner as any other Windows executable.

However, the MYSTRAN-Installation-and-Run-Manual.pdf provides additional run options, which may increase flexibility (3 options are provided).
This installation/run file also provides information about command window messages and basic file outputs.
See the relevant thread and Documentation Zip file at https://www.mystran.com/forums/

The user manual is also locate on the MYSTRAN forums.
See the relevant thread and Documentation Zip file at https://www.mystran.com/forums/