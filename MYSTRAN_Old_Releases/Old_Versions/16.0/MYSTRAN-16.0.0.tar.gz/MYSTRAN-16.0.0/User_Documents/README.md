NOTE: TOC needs update.

NOTE: GitHub sometimes has issues with PDF files being corrupted, so a ZIP is also included.

