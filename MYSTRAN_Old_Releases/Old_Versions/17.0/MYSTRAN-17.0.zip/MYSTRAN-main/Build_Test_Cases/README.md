These cases are used to check that the build runs and produces a valid result (quick check).
They are not the complete set of benchmark test cases.
For the complete set of benchmark test cases, see the MYSTRAN_Benchmark repository.