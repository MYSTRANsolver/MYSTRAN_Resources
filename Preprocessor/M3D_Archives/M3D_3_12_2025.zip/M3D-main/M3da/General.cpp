

//************************************************************************************
// Pre  : File name
// Post : Returns the path without the file name or "NULL"
//************************************************************************************
CString getPath(CString FName)
{
CString src;
//Dim iP As Long
//src = "NULL"
//iP = InStr(FName, ":")
//If iP > 1 Then
 // src = Left(FName, GetLastChar(FName, "\"))
//End If
//getPath = src
return (src);
}
End Function