

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Mon Jan 18 22:14:07 2038
 */
/* Compiler settings for M3da.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.01.0628 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        EXTERN_C __declspec(selectany) const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif // !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, LIBID_M3da,0x28298EED,0x2921,0x46EF,0x91,0x77,0x73,0x08,0x5F,0x11,0x18,0x28);


MIDL_DEFINE_GUID(IID, DIID_IM3da,0xD0A70CB8,0x1A81,0x462F,0x91,0x71,0x84,0xEF,0xAB,0x11,0xDD,0x21);


MIDL_DEFINE_GUID(CLSID, CLSID_CM3daDoc,0xA7226713,0x7CA7,0x4243,0x8B,0x24,0x4C,0x7A,0xA3,0x6D,0x1F,0xA3);


MIDL_DEFINE_GUID(IID, DIID_IDBase,0x45542F2E,0x3541,0x4330,0x9B,0xE0,0xA4,0xB5,0x9B,0x3D,0x39,0x2C);


MIDL_DEFINE_GUID(CLSID, CLSID_DBase,0xD619E744,0x24BA,0x46CF,0x9D,0xF3,0x4E,0x44,0xAE,0xBA,0x44,0x7B);


MIDL_DEFINE_GUID(IID, DIID_IObject,0x2EC99D19,0x8632,0x44E0,0xA2,0x2E,0x29,0x4C,0xFB,0x4F,0x5D,0x61);


MIDL_DEFINE_GUID(CLSID, CLSID_G_Object,0x50FB7579,0x3C0F,0x4B23,0xBF,0x30,0xF9,0xC8,0x8B,0x31,0xC3,0x07);


MIDL_DEFINE_GUID(IID, DIID_IME_Object,0x190D2974,0x17B6,0x4295,0xA4,0xC5,0x08,0xFA,0x06,0xFC,0x6C,0xD9);


MIDL_DEFINE_GUID(CLSID, CLSID_ME_Object,0x7C1C0A34,0x5974,0x452F,0x96,0xE7,0xDB,0x7F,0x46,0x41,0x2B,0x29);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



